package com.siemens.spring.service;

import java.util.List;

import com.siemens.spring.core.Employee;

public interface EmployeeService {

	public abstract void insertEmployee(Employee emp);
	public abstract void deleteEmployee(int empId);
	public abstract void updateEmployee(Employee emp);
	public abstract void fetchEmployeeById(int empId);
	public abstract List<Employee> fetchAllEmployees();
}
