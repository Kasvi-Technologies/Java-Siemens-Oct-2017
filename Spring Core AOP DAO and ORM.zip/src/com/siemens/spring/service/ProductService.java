package com.siemens.spring.service;

import com.siemens.spring.core.Product;

public interface ProductService {

	public void addProduct(Product p);
}
