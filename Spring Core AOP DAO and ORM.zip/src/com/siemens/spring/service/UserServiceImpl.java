package com.siemens.spring.service;

import org.springframework.transaction.annotation.Transactional;

import com.siemens.spring.core.User;
import com.siemens.spring.dao.UserDAO;

@Transactional
public class UserServiceImpl implements UserService{

	private UserDAO userDAO;
	
	public UserDAO getUserDAO() {
		return userDAO;
	}

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	@Override
	@Transactional
	public void insertUser(User u) {
		// TODO Auto-generated method stub
		this.userDAO.insertUser(u);
		
	}

}
