package com.siemens.spring.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.siemens.spring.core.Stock;
import com.siemens.spring.dao.StockDAO;

@Transactional
public class StockServiceImpl implements StockService{

	private StockDAO stockDAO;
	
	public StockDAO getStockDAO() {
		return stockDAO;
	}

	public void setStockDAO(StockDAO stockDAO) {
		this.stockDAO = stockDAO;
	}

	@Override
	@Transactional
	public void insertStock(Stock stock) {
		// TODO Auto-generated method stub
		stockDAO.insertStock(stock);
	}

	@Override
	public List<Stock> fetchAllStocks() {
		// TODO Auto-generated method stub
		return stockDAO.fetchAllStocks();
	}

}
