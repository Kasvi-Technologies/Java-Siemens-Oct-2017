package com.siemens.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.siemens.spring.core.Product;
import com.siemens.spring.dao.ProductDAO;

@Service("productService")
public class ProductServiceImpl implements ProductService{

	private ProductDAO productDAO;
	
	public ProductDAO getProductDAO() {
		return productDAO;
	}

	@Autowired
	@Qualifier("productDAO")
	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		System.out.println("adding product" + p.getId());
		productDAO.addProduct(p);
	}

}
