package com.siemens.spring.service;

import java.util.List;

import com.siemens.spring.core.Stock;

public interface StockService {

	public void insertStock(Stock stock);
	public List<Stock> fetchAllStocks();
}
