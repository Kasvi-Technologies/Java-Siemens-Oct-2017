package com.siemens.spring.service;

import com.siemens.spring.core.User;

public interface UserService {

	public void insertUser(User u);
}
