package com.siemens.spring.aop;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

public class CustomerBeforeAspect 
			implements MethodBeforeAdvice{

	@Override
	public void before(Method method, 
					   Object[] arguements, 
					   Object target) throws Throwable {
		
		System.out.println("CustomerBeforeAspect:before method");
		System.out.println("Calling method " 
							+method.getName());
		System.out.println("return type of method" + method.getReturnType());
		System.out.println("CustomerBeforeAspect:Busnesslogic");
		System.out.println("CustomerBeforeAspect:before method completed..");
	}
}
