package com.siemens.spring.aop;

import org.springframework.aop.ThrowsAdvice;

public class CustomerThrowsAspect 
						implements ThrowsAdvice{

//	public void afterThrowing(EmployeeException e)
//			throws Exception {
//
//			System.out.println("CustomerThrowsAspect:");
//			System.out.println("CustomerThrowsAspect:" 
//						+e.getMessage());
//	}
	
	public void afterThrowing(Exception e)
						throws Exception {
		
		System.out.println("CustomerThrowsAspect:");
		System.out.println("CustomerThrowsAspect:" 
									+e.getMessage());
			
	}
}
