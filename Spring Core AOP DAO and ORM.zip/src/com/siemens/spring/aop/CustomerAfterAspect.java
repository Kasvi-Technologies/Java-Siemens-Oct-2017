package com.siemens.spring.aop;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

//This Aspect can be executed after completion of
//original (target object) methods

public class CustomerAfterAspect 
			implements AfterReturningAdvice{

	@Override
	public void afterReturning(Object returnValue, 
			Method method, 
			Object[] arguements, 
			Object target) throws Throwable {
		
		System.out.println("CustomerAfterAspect:afterReturning");
		System.out.println(method.getName());
		
	}

}
