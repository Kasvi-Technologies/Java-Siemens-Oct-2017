package com.siemens.spring.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Stock;
import com.siemens.spring.service.EmployeeService;
import com.siemens.spring.service.StockService;

public class StockHibernateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
		new ClassPathXmlApplicationContext("daobeans.xml");		
		
		StockService stockService = 
				context.getBean("stockService",
								StockService.class);		
		Stock stock = new Stock();
		stock.setStockName("Maruthi Suzuki");
		stock.setPrice(8000);		
		
		
		stockService.insertStock(stock);
		
		//Fetch all stocks...
		List<Stock> stockList = 
				stockService.fetchAllStocks();
		for(Stock stock1: stockList){
			System.out.println(stock1.getStockId() + " " +
						stock.getStockName());			
		}
		
	}

}
