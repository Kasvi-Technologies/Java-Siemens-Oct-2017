package com.siemens.spring.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Employee;
import com.siemens.spring.service.EmployeeService;

public class DAOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
				new ClassPathXmlApplicationContext("daobeans.xml");
		
		EmployeeService empService = 
				context.getBean("employeeService",
								EmployeeService.class);
		
//		Employee emp = new Employee();
//		emp.setId(10);
//		emp.setName("sadsad");
//		emp.setSalary(13213);
//		
//		empService.insertEmployee(emp);
		
		//empService.deleteEmployee(10);
		List<Employee> empList = 
				empService.fetchAllEmployees();
		
		for (Employee emp : empList){
			System.out.println(emp.getId() 
					+ " " + emp.getName()
					+ " " + emp.getSalary());
		}
		
		System.out.println("Done..............");
	
		
		
	}

}
