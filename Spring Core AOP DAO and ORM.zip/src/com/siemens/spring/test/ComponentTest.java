package com.siemens.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Product;
import com.siemens.spring.service.ProductService;

public class ComponentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = 
		new ClassPathXmlApplicationContext("components.xml");
		
		//Here variable name is similar to class name 
		//but should starts with a small letter 
		
		Product product = 
				factory.getBean("product", Product.class);
		product.setId(100);
		
		System.out.println(product.getId());
		
		ProductService productService = 
				factory.getBean("productService", 
						ProductService.class);
		
		productService.addProduct(product);
		
	}

}
