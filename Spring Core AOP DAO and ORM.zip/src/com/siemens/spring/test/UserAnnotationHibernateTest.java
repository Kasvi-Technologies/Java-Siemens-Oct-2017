package com.siemens.spring.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Stock;
import com.siemens.spring.core.User;
import com.siemens.spring.service.EmployeeService;
import com.siemens.spring.service.StockService;
import com.siemens.spring.service.UserService;

public class UserAnnotationHibernateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
		new ClassPathXmlApplicationContext("annotationhbdaobeans.xml");		
		
		UserService userService = 
				context.getBean("userService",
								UserService.class);		
		User user = new User();
		user.setUserName("nns  kkjkkadsadsad");
		user.setPassword("sadasd");
		user.setAge(100);
		
		userService.insertUser(user);
		System.out.println("done..");
	}

}
