package com.siemens.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.aop.Customer;

public class CcustomerBeforeProxytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
				new ClassPathXmlApplicationContext("aopbeans.xml");
				
		Customer customer = 
				context.getBean("customerBeforeProxy", 
						Customer.class);
				
		customer.printName();
		customer.printURL();
				
		try {
			customer.throwsExceptionMethod();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

}
