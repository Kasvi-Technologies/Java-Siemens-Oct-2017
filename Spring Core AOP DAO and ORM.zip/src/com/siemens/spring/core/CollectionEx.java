package com.siemens.spring.core;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionEx {

	private List aList;
	private Set aSet;
	private Map amap;
	
	public List getaList() {
		return aList;
	}
	public void setaList(List aList) {
		this.aList = aList;
	}
	public Set getaSet() {
		return aSet;
	}
	public void setaSet(Set aSet) {
		this.aSet = aSet;
	}
	public Map getAmap() {
		return amap;
	}
	public void setAmap(Map amap) {
		this.amap = amap;
	}
	
	
}
