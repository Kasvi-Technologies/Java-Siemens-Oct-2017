package com.siemens.spring.dao;

import java.util.List;

import com.siemens.spring.core.Stock;

public interface StockDAO {
	public void insertStock(Stock stock);
	public List<Stock> fetchAllStocks();
	
}
