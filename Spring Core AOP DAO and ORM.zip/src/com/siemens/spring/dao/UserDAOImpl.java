package com.siemens.spring.dao;

import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import com.siemens.spring.core.User;

public class UserDAOImpl extends HibernateDaoSupport implements UserDAO{
	
	public void insertUser(User u){
		this.getHibernateTemplate().setCheckWriteOperations(false);
		this.getHibernateTemplate().save(u);
	}

}
