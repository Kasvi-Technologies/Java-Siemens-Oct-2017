package com.siemens.spring.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

import com.siemens.spring.core.Stock;

public class StockDAOImpl extends HibernateDaoSupport
						implements StockDAO {

	//SessionFactory variable  and setter and getter
	//available in HibernateDAOSupport
	
	@Override
	public void insertStock(Stock stock) {
		this.getHibernateTemplate()
				.setCheckWriteOperations(false);
		this.getHibernateTemplate().save(stock);
	}

	@Override
	public List<Stock> fetchAllStocks() {
		// TODO Auto-generated method stub
		List<Stock> stockList = (List<Stock>)
				this.getHibernateTemplate().find("from Stock");
		return stockList;
	}

}
