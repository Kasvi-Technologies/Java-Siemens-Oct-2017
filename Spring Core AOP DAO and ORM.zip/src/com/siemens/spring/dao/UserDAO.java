package com.siemens.spring.dao;

import com.siemens.spring.core.User;

public interface UserDAO {

	public void insertUser(User u);
}
