package com.siemens.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


import com.siemens.spring.core.Employee;

//setDataSource method is available in JdbcDaoSupport

public class EmployeeDAOImpl 
					extends JdbcDaoSupport implements EmployeeDAO{

	@Override
	public void insertEmployee(Employee emp) {
		int id = emp.getId();
		String name = emp.getName();
		double salary = emp.getSalary();
		System.out.println("DAO:insertEmployee" );
		
		String insertQry = "insert into employee1 "
				+ "(id, name, salary) values "
				+ "("+id+" , '"+name+"' , "+salary+")";
	
		this.getJdbcTemplate().update(insertQry);
		System.out.println("Insertion completd..");
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		System.out.println("DAO:deleteEmployee" );		
		String deleteQry = "delete from employee1 where"
				+ " id = " + empId;		
		this.getJdbcTemplate().update(deleteQry);
		System.out.println("deletion completd.." +empId);
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("DAO:updateEmployee" );
	}

	@Override
	public void fetchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		System.out.println("DAO:fetchEmployeeById" );
		
		
	}

	@Override
	public List<Employee> fetchAllEmployees() {
		System.out.println("DAO:fetchAllEmployees" );		
		String fetchQry = "select * from employee1";		
		List<Employee> empList = 
			this.getJdbcTemplate().query(fetchQry, 
			new RowMapper<Employee>(){
				@Override
				public Employee mapRow(ResultSet rs
					, int arg1) throws SQLException {					
					Employee emp = new Employee();
					emp.setId(rs.getInt("id"));
					emp.setName(rs.getString("name"));
					emp.setSalary(rs.getDouble("salary"));					
					return emp;
				}
		});		
		return empList;
				
	}	

}
