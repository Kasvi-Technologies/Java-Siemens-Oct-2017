package com.siemens.spring.dao;

import com.siemens.spring.core.Product;

public interface ProductDAO {
	public void addProduct(Product p);
}
