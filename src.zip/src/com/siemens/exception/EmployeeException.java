package com.siemens.exception;

//Exception class is from java.lang package
// No need to import java.lang package related classes

public class EmployeeException extends Exception {

	public EmployeeException (String message) {
		this.message = message;
	}
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
