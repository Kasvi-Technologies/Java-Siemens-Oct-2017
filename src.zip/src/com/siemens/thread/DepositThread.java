package com.siemens.thread;

import com.siemens.service.BankAccount;

public class DepositThread extends Thread{

	private BankAccount bankAccount;
	
	public DepositThread(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	
	public void run(){
		System.out.println("started DepositThread..."
					+ this.getName());
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bankAccount.deposit(500);
		System.out.println("completed DepositThread...");
	}
}
