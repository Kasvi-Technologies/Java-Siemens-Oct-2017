package com.siemens.thread;

import java.util.ArrayList;
import java.util.List;

public class SMSRunnable implements Runnable {

	//run() is the default method which will be
	//called by start() method...
	
	private List<Integer> accountIds 
						= new ArrayList<Integer>();
	//write setter and getter methods for accountIds var.
	
	public void run() {
		System.out.println("Started SMSThread......");
		
		for (Integer accountId: this.getAccountIds()){
			System.out.println("Sending SMS to " + accountId);
			
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Completed SMSThread...");
		
	}
	
	public List<Integer> getAccountIds() {
		return accountIds;
	}

	public void setAccountIds(List<Integer> accountIds) {
		this.accountIds = accountIds;
	}
	
}
