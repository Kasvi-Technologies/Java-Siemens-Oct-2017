package com.siemens.thread;

import com.siemens.service.BankAccount;

public class WithdrawThread extends Thread{

private BankAccount bankAccount;
	
	public WithdrawThread(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	
	public void run(){
		System.out.println("started WithdrawThread..." 
								+this.getName());
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		bankAccount.withdraw(500);
		System.out.println("completed WithdrawThread...");
	}
}
