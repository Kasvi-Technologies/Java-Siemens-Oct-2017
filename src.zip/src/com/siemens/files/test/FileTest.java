package com.siemens.files.test;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File f = new File("C:\\HelloWorld.java");
		
		System.out.println("Is exists:" + f.exists());
		f.canWrite();
		f.canRead();
		f.canExecute();
		
		//If the file does not exists,  and you want 
		//to create a new file
		
		try {
			f.createNewFile(); // used to create a file
			//if it not exists
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Is Directory:" + f.isDirectory());
		System.out.println("Is File:" + f.isFile());
		
		System.out.println("path:" + f.getAbsolutePath());
		
		f.lastModified();
		
		Date d = new Date(f.lastModified());
		System.out.println(d);
		
		//f.delete(); //delete a file
		
		
		System.out.println("Done...");
		
		File f1 = new File("C:" + File.separator + "anil");
		
		System.out.println("is Dir:" + f1.isDirectory());
		
		if (f1.isDirectory()) {
			String list[] = f1.list();
			
			for (String str : list){
				System.out.println(str);
			}
		}
	}

}
