package com.siemens.files.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.siemens.beans.Employee;

public class ObjectReadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f = new File("C:\\EmployeeObjectsState.txt");
		
		try {
			FileInputStream fIn = 
							new FileInputStream(f);
			
			ObjectInputStream oIn = 
						    new ObjectInputStream(fIn);
			
			//De-serialization
			Employee emp = (Employee) oIn.readObject();
			
			System.out.println(emp);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
