package com.siemens.files.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileReadExTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f = new File("C:\\HelloWorld.java");
		
		try {
			FileInputStream fin = 
								new FileInputStream(f);
			int b;
			while ((b = fin.read()) != -1) {
				System.out.print((char)b);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
