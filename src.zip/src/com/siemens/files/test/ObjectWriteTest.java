package com.siemens.files.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.siemens.beans.Employee;

public class ObjectWriteTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File f = new File("C:\\EmployeeObjectsState.txt");
		
		try {
			FileOutputStream fout = 
							new FileOutputStream(f);
			
			ObjectOutputStream oOut = 
					new ObjectOutputStream(fout);
			
			Employee emp = 
					new Employee(32, "sfd","dsf",32,32);
			
			//This process is called Serialization
			//Writing the state of an object into files
			//implements Serializable
			
			oOut.writeObject(emp);
			System.out.println("Done...............");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
