package com.siemens.service;

import java.util.List;

import com.siemens.beans.Employee;
import com.siemens.exception.EmployeeException;

public abstract class EmployeeService {

	public abstract void insertEmployee(Employee emp) 
									throws  EmployeeException;
	public abstract void deleteEmployee(int empId);
	public abstract void updateEmployee(Employee emp);
	public abstract void fetchEmployeeById(int empId);
	public abstract List<Employee> fetchAllEmployees();
	
}
