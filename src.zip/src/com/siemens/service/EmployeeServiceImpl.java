package com.siemens.service;

import java.util.List;

import com.siemens.beans.Employee;
import com.siemens.dao.EmployeeDAO;
import com.siemens.dao.EmployeeDAOImpl;
import com.siemens.exception.EmployeeException;

public class EmployeeServiceImpl extends EmployeeService{

	private EmployeeDAO empDAo = new EmployeeDAOImpl();
	
	@Override
	public void insertEmployee(Employee emp) 
						throws  EmployeeException {
		// TODO Auto-generated method stub
		System.out.println("inserting employee:" + emp.getEmpId());
		
		if (emp.getEmpId() <= 0) {
			throw new EmployeeException("Id value should be "
					+ "greater than zero");
		}
		
		empDAo.insertEmployee(emp);
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		System.out.println("deleting employee:" + empId);
		empDAo.deleteEmployee(empId);
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("updating employee:" + emp.getEmpId());
		empDAo.updateEmployee(emp);
		
	}

	@Override
	public void fetchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		
		System.out.println("fetch employee of :" + empId);
		empDAo.fetchEmployeeById(empId);
	}

	@Override
	public List<Employee> fetchAllEmployees() {
		// TODO Auto-generated method stub
		System.out.println("fetch All employees:" );
		//BL
		//BL
		//DL
		List<Employee> empList = empDAo.fetchAllEmployees();
		return empList;
	}

}
