package com.siemens.service;

public class BankAccount {

	private int amount;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	public synchronized void withdraw(int amount){
		System.out.println("Withdraw started..");
		
		if (this.amount <= 1000) {
			try {
				System.out.println("Waiting state......");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Waiting completed......");
		this.amount = this.amount - amount;
		
		System.out.println("Withdraw Completed...." + this.amount);
	}
	
	public synchronized void deposit(int amount){
		System.out.println("Deposit started..");
		
		this.amount = this.amount + amount;
		
		notify();
		
		System.out.println("Deposit Completed...." + this.amount);
	}
	
}
