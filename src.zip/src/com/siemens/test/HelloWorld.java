package com.siemens.test;
public class HelloWorld {

	public static void main(String[] args) {
		
		for (int i= 0 ; args!=null && i<args.length; 
				i++) {
			System.out.println(args[i]);
			
		}
		
		
		System.out.println("Basic Java App.......");
		
		//Example of Data Types
		//This is a comments, so that java compiler 
		//will ignore the comments at the time of 
		//compilation and execution
		//Syntax
		//Datatype variablename = Value;
		
		byte b = 10;
		int i = 100;
		float f = 10.05f;
		double d = 356.56;
		
		char ch = 'a';
		boolean flag  = true;
		
		//operators -> + - * / %
		System.out.println(i*f);
		
		int byte1 = 10;
		
		sum(5,6);
		
		int k=100, p =200;
		
		//<, > ,<=, >=, ==
		//&&, || , !=
		
		if (k < p ) {
			System.out.println("here k is lessthan p...");
		} else if (k<200) {
			System.out.println("here k is 200...");
		} else {
			System.out.println("here p is lessthan k");
		}
		
	} // closing statement of main method.
	
	//Example of method...
	public static void sum (int a, int b) {
		
		int sum = a+b;
		System.out.println(sum);
	}

}
