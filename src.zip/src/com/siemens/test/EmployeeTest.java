package com.siemens.test;

import com.siemens.beans.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Classname variablename = new Classname();
		
		Employee emp1 = new Employee();
		emp1.setEmpId(100);
		emp1.setEmpName("Siemens Emp1");
		emp1.setEmailId("emp1@siemens.com");
		emp1.setMobile(232132);
		emp1.setSalary(50000.50);
		
		System.out.println(emp1);
		//emp1.toString()
		
		
		Employee emp2 = new Employee();
		emp2.setEmpId(100);
		emp2.setEmpName("Siemens Emp1");
		emp2.setEmailId("emp1@siemens.com");
		emp2.setMobile(232132);
		emp2.setSalary(50000.50);
		
		//Paremeterized contructors..
		Employee emp3 = new Employee(300, "Siements emp3",
				"emp2@siemens.com", 55, 65765);
		
		
		Employee emp4 = new Employee(400, "Siements emp4",
				"emp4@siemens.com", 355, 565765);
		
		
		//System.out.println(emp2);
		
		//System.out.println(emp3);
		
		
	}

}
