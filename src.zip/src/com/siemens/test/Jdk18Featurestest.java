package com.siemens.test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import com.siemens.beans.Employee;

public class Jdk18Featurestest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//forEach method
		//Lambda expressions
		//functional interfaces
		
		
		List<Integer> intLst = new ArrayList<Integer>();
		intLst.add(100);
		intLst.add(200);
		intLst.add(300);
		intLst.add(400);
		
		System.out.println("Normal for loop");
		for (Integer i : intLst) {
			System.out.println(i);
		}
		
		System.out.println("JDK 1.8 forEach methods..");
		
		//Example of anonymous inner class
		Consumer<Integer> c = new Consumer<Integer>() {
			@Override
			public void accept(Integer arg0) {
				//business logic based on list values
				System.out.println(arg0);
			}
		};
		
		Consumer<Integer> c1 = (i) -> {
			System.out.println(i);
		};
		
		intLst.forEach(c);	
		intLst.forEach(new MyConsumer());
		intLst.forEach(c1);
		//Functional Interface
		// An interface which contains only one abstract method
		
		//Lambda expression
		//Combination of Anonymous Inner classes and Functonal interfaces
		// Anonymous inner classes+ Functional interfaces
		
		//will simplify your code 
		//but there wont be any advantage
		Employee e = new Employee(1,"dsf","fds",56,65);
		
		EmpInterface<Employee> emp = new EmpInterface<Employee>() {
			@Override
			public void addEmployoyee(Employee e) {
				System.out.println(e);
			}
		};
		
		emp.addEmployoyee(e);
		
		//Using Lambda expression
		EmpInterface<Employee> emp1 = (e1) -> {
			System.out.println(e1);
		};
		emp1.addEmployoyee(e);
	}
}//class closing

@FunctionalInterface
interface EmpInterface<Employee> {
	public void addEmployoyee(Employee emp);
}

class MyConsumer implements Consumer<Integer> {
	@Override
	public void accept(Integer arg0) {
		System.out.println(arg0);
	}
}






