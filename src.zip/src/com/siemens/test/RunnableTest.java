package com.siemens.test;

import java.util.ArrayList;
import java.util.List;

import com.siemens.thread.MailRunnable;
import com.siemens.thread.MailThread;
import com.siemens.thread.SMSRunnable;
import com.siemens.thread.SMSThread;

public class RunnableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Started Main Method...");
		List<Integer> accountIds 
						= new ArrayList<Integer>();

		for (int i=100;i<=200;i++) {
			accountIds.add(i);
		}
		
		SMSRunnable sr = new SMSRunnable();
		MailRunnable mr = new MailRunnable();
		
		sr.setAccountIds(accountIds);
		mr.setAccountIds(accountIds);		
		
		Thread smsThread = new Thread(sr);
		Thread mailThread = new Thread(mr);
		
		smsThread.start();
		mailThread.start();
		
		try {
			smsThread.join();
			mailThread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Completed Main Method...");
		
	}

}
