package com.siemens.test;

import com.siemens.service.BankAccount;
import com.siemens.thread.DepositThread;
import com.siemens.thread.WithdrawThread;

public class BankAccountTest {

	public static void main(String[] args){
		
		System.out.println("Main method started...");
		
		BankAccount bankAccount = new BankAccount();
		bankAccount.setAmount(1000);
		
		WithdrawThread wt = new WithdrawThread(bankAccount);
		DepositThread dt = new DepositThread(bankAccount);
		
		dt.start();
		wt.start();
		try {
			wt.join();
			dt.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Main method completed...");
	}
}
