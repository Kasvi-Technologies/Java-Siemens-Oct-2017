package com.siemens.test;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.siemens.beans.Employee;

public class ExecutorServceCallableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExecutorService service = 
					Executors.newFixedThreadPool(2);
		
		Callable<Employee> callable = new Callable<Employee>(){
			public Employee call() throws Exception {
		
				Employee e = new Employee(1, "asd", "sad",3,3);
				return e;
			}
		};
		
		Future<Employee> f = service.submit(callable);
		try {
			Employee emp = f.get();
			System.out.println(emp);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		service.shutdown();
	}

}
