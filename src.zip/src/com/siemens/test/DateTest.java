package com.siemens.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Date d = new Date();
		System.out.println(d);
		
		String pattern = "dd/MM/yyyy HH:mm:SS";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		System.out.println(sdf.format(d));
		
		String pattern1 = "yyyy/MM/dd";
		sdf = new SimpleDateFormat(pattern1);
		System.out.println(sdf.format(d));
		
		String pattern2 = "yyyy/MMM/dd";
		sdf = new SimpleDateFormat(pattern2);
		System.out.println(sdf.format(d));
		
		System.out.println("Convert String into Date..");
		String dateStr = "25/10/2017";
		String pattern3 = "dd/MM/yyyy";
		sdf = new SimpleDateFormat(pattern3);
			 
		try {
			Date d1 = sdf.parse(dateStr);
			System.out.println(d1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
