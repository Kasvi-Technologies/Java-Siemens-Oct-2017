package com.siemens.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.siemens.service.BankAccount;
import com.siemens.thread.DepositThread;
import com.siemens.thread.WithdrawThread;

public class ExecutorServicetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ExecutorService service = 
					Executors.newFixedThreadPool(2);
		
		BankAccount bankAccount = new BankAccount();
		bankAccount.setAmount(1000);
		
		WithdrawThread wt = new WithdrawThread(bankAccount);
		DepositThread dt = new DepositThread(bankAccount);
		wt.setPriority(10);
		
		service.execute(wt); 
		service.execute(dt); 
		service.execute(wt);
		service.execute(dt);//Thread0	
		service.execute(wt);
		service.execute(dt);
		service.execute(wt);
		service.execute(dt);
		service.execute(wt); //Thread1
		service.execute(dt);
		
		service.shutdown();
		
		
	}	

}
