package com.siemens.test;

import com.siemens.beans.Employee;
import com.siemens.exception.EmployeeException;
import com.siemens.service.EmployeeService;
import com.siemens.service.EmployeeServiceImpl;

public class EmployeeServicetest {

	private static  final int i = 10;
	
	public static void getValue(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		getValue();
		
		EmployeeService empService = new EmployeeServiceImpl();
		
		Employee emp = new Employee();
		emp.setEmpId(100);
		emp.setEmpName("Siemens Emp1");
		emp.setEmailId("emp1@siemens.com");
		emp.setMobile(232132);
		emp.setSalary(50000.50);
		
		try {
			empService.insertEmployee(emp);
			empService.deleteEmployee(100);
			empService.updateEmployee(emp);
			empService.fetchEmployeeById(100);
			empService.fetchAllEmployees();
		} catch (EmployeeException ee) {
			System.out.println("execption occured:" 
								+ ee.getMessage());
		}
		
				
	}

}
