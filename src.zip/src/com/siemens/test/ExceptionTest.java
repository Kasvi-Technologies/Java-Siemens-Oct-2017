package com.siemens.test;

import com.siemens.exception.EmployeeException;
import com.siemens.service.EmployeeService;
import com.siemens.service.EmployeeServiceImpl;

public class ExceptionTest {

	public static void example (int id) 
				throws EmployeeException, Exception {
		
		if (id <= 0) {
			throw new EmployeeException("Id value should be "
					+ "greater than zero");
		}
		
		//BL based on id
	}
	
	public static void main(String[] args) 
									throws Exception {
		System.out.println("Before Exception....");		
		try {
			example(-80);
			//BL, which might cause the errors/exceptions
			// EmployeeService emp = null;
			EmployeeService emp = new EmployeeServiceImpl();
			emp.fetchAllEmployees(); 
			//Performing Operations on a Nullable Object
			//can lead to NullPointerException and terminate
			//the application...
			
			//int a = 10/0; // ArithmeticException
			
			int a = 10/5;
			
			int b[] = new int[2];
			b[1] = 100; //ArrayIndexOutOfBoundsException
			
			
			
		} catch (NullPointerException npe) {
			System.out.println("NullPointerException occured..");
			npe.printStackTrace();
		} catch (ArithmeticException ae) {
			System.out.println("ArithmeticException occured..");
			ae.printStackTrace();
		} catch (ArrayIndexOutOfBoundsException aioe) {
			System.out.println("ArrayIndexOutOfBoundsException occured..");
			aioe.printStackTrace();
		}catch (EmployeeException e) {
			System.out.println("Employee Exception occured..");
			throw e;
		} catch (Exception e) {
			System.out.println("Exception occured..");
			e.printStackTrace();
			throw e;
		} finally {
			System.out.println("always executed...");
		}
				
		System.out.println("After Exception....");
		
	}
	
	

}
