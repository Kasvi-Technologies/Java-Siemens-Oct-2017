package com.siemens.test;

import com.siemens.beans.Bike;
import com.siemens.beans.Car;
import com.siemens.beans.Vehicle;

public class VehicleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Car c = new Car();
		//ParentClass variable = new ChildClass();
		
		Vehicle c = new Bike();
		c.setvId(100);
		c.setVname("Maruthi");
		c.setCost(3565655);		
		c.drive(); //runtime, 
		
		// vehicle method or car method, which method
		// it needs to be executed
		
		//c.drive(50);  // Compile time polymorphism
		
		Vehicle b = new Car();
		b.setvId(168);
		b.setVname("Hero");
		b.setCost(8786);		
		b.drive();
		
		System.out.println("Example of Polymorphism...");
		
		
	}

}
