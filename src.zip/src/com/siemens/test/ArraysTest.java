package com.siemens.test;
import com.siemens.beans.Employee;

public class ArraysTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//To hold multiple values at the same time 
		//and same data type
		
		int a[] = new int[10];
		//0 to 9
		
		System.out.println(a.length);
		
		for (int i =0; i< a.length; i++) {
			a[i] = i ;
		}
		//enhanced for loops
		for (int in : a){
			System.out.println(in);
		}
		
		System.out.println("Squre of 9 is:" + a[9]);
		
		Employee emp[] = new Employee[3];
		
		Employee emp1 = new Employee(300, "Siements emp3",
				"emp2@siemens.com", 55, 65765);			
		Employee emp2 = new Employee(400, "Siements emp4",
				"emp4@siemens.com", 355, 565765);		
		Employee emp3 = new Employee(400, "Siements emp4",
				"emp4@siemens.com", 555, 565765);
		
		emp[0] = emp1;
		emp[1] = emp2;
		emp[2] = emp3;
		double totalSal = 0;
		double totalHikesSal = 0;
//		for (int i=0; i<emp.length;i++){
//			totalSal = totalSal + emp[i].getSalary();
//			totalHikesSal = totalHikesSal + 
//					salaryHike(emp[i].getSalary(), 10);
//		}
		
		//Enhanced for loop for employee..
		
		for (Employee employee : emp){
			totalSal = totalSal + employee.getSalary();
			totalHikesSal = totalHikesSal + 
					salaryHike(employee.getSalary(), 10);
		}
		
		System.out.println(totalSal);
		System.out.println(totalHikesSal);
	}

	public static double salaryHike(double salary, int hike){
		return salary + (salary *hike/100);
	}
}
