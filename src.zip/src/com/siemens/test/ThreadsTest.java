package com.siemens.test;

import java.util.ArrayList;
import java.util.List;

import com.siemens.thread.MailThread;
import com.siemens.thread.SMSThread;

public class ThreadsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Started Main Method...");
		List<Integer> accountIds 
						= new ArrayList<Integer>();

		for (int i=100;i<=200;i++) {
			accountIds.add(i);
		}
		
		SMSThread st = new SMSThread();
		MailThread mt = new MailThread();
		
		st.setAccountIds(accountIds);
		mt.setAccountIds(accountIds);
		
		st.start();
		mt.start();
		
		try {
			st.join();
			mt.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Completed Main Method...");
	}

}
