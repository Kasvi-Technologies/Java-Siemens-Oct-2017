package com.siemens.test;

import java.util.StringTokenizer;

public class StringExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = new String("My First First String examples");
		
		String str1 = "My First String examples";
		
		System.out.println("str:" + str);
		
		System.out.println("str1:" + str1);
		
		System.out.println("toLowercase:" + str.toLowerCase());
		
		System.out.println("to Uppercase:" +str.toUpperCase());
		
		System.out.println("Location of F: " + str.indexOf("F"));
		
		System.out.println("Location of example"
									+ str.indexOf("example"));
		
		System.out.println("Location of s search "
				+ "from last: " + str.lastIndexOf("s"));
		
		System.out.println("Sub String with in 3 and 15:" 
						+ str.substring(3, 15));
		
		System.out.println("Sub String from index 5 onwards:" 
				+ str.substring(5));
		
		int index = str.indexOf("First");
		
		System.out.println("Second first:" 
		            + str.indexOf("First", index+1));
		
		str.endsWith("examplas");
		
		str.trim(); // will remove extra spaces
		
		String[] strWords = str.split(" ");
		//divide your string based on delimeters
		//here, delimeter i used is space
		
		for (String word : strWords){
			System.out.println(word);
		}
		
		
		System.out.println("Example of String Buffer...");
		
		String str5 ="Hi";
		str5 = str5 + " Good ";		
		str5 = str5 + " Morning ";
		
		System.out.println(str5);
		
		//ADV: it will not create multiple memory 
		// locations and all modifications will happen
		// at one particular memory location
		
		String hi = "Hi";
		StringBuffer sb = new StringBuffer(hi);
		sb.append("Good");
		sb.append("Morning");
		
		String st6 = sb.reverse().toString();
		System.out.println("Using String Buffer:" + st6);
		
		System.out.println("StringBuilder Example!!!");
		String hi1 = "Hi";
		StringBuilder sb1 = new StringBuilder(hi1);
		sb1.append("Good");
		sb1.append("Morning");
		
		String st7 = sb1.reverse().toString();
		System.out.println("Using String Builder:" + st7);
		
		String str8 = new String("My First First String examples");
		
		System.out.println("using String Tokenizer!!!");
		StringTokenizer st = 
						new StringTokenizer(str8, " ");
		
		while(st.hasMoreTokens()) {
			String token = st.nextToken();
			System.out.println(token);
		}
		
		
		
	}

}





