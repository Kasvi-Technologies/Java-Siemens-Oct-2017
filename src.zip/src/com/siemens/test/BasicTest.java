package com.siemens.test;

public class BasicTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Sequential order..................
		
		System.out.println("Started.....");
		
		for (int i = 0; i< 100; i++) {
			System.out.println("First For Loop:" + i);
		}
		
		for (int j = 0; j< 100; j++) {
			System.out.println("Second For Loop:" + j);
		}
		
		System.out.println("Remaining Business logic place");
		System.out.println("Completed.....");
	}

}
