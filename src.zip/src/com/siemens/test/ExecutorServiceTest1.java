package com.siemens.test;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main started...");
		ExecutorService service = 
				Executors.newFixedThreadPool(2);
	
		//service.execute(thread or runnable);
		
		//Anonymous inner class
		//on the fly , object will be created.
		//Generally, object can't be created for interfaces
		
		Runnable runnable = new Runnable() {
			public void run(){
				System.out.println("Ex of Anonymous class");
			}
		};
		
		service.execute(runnable); 
		// will execute run method in the background.. 
		
		// To know, if run method executed succesfully or
		// any exception occurs
		
		Future future = service.submit(runnable);
		try {
			String status = (String) future.get();
			System.out.println(status);
			//get method return null, if success
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		System.out.println("Example of callable interface!!!");
		Future<String> future1 = 
					service.submit(new MyCallableEx());
		
		try {
			String status = future1.get();
			System.out.println("status:" + status);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		service.shutdown();
		System.out.println("Main completed...");
	}

} // class ending


class MyCallableEx implements Callable<String> {

	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Callble interface example.");
		return "success";
	}
	
	
	
}







