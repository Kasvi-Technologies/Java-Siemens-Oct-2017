package com.siemens.test;

import com.siemens.beans.Calculator;
import com.siemens.beans.CalculatorImpl;

public class CalculatorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calculator cal = new CalculatorImpl();
		System.out.println(cal.sum(5, 6));
		System.out.println(cal.minus(5, 6));
	
	}

}
