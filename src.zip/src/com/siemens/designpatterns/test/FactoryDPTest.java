package com.siemens.designpatterns.test;

import com.siemens.beans.Bike;
import com.siemens.beans.Car;
import com.siemens.beans.Vehicle;

public class FactoryDPTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Factory Design pattern
		
		// it should return one of the class from its 
		// family hierarchy
		Vehicle v = getVehicle("bike");
		v.drive();
	}
	
	public static Vehicle getVehicle(String vehicleType){
		
		if("car".equals(vehicleType)){
			return new Car();
		} else if("bike".equals(vehicleType)){
			return new Bike();
		}
		//if xyz
		//if Hero
		
		return null;
		
	}

}
