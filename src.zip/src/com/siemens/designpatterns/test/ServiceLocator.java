package com.siemens.designpatterns.test;

import com.siemens.service.EmployeeService;
import com.siemens.service.EmployeeServiceImpl;

//centralized place to return all services

//register all services with ServiceLocator

// whenever you need, you can call servicelocator to
//get the service

public class ServiceLocator {

	public static EmployeeService getEmployeeService(){
		return new EmployeeServiceImpl();
	}
	
//	public MobileService getMobileService(){
//		return new MobileServiceImpl();
//	}
}
