package com.siemens.designpatterns.test;

public class SingletonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SingletonExample s1 = 
					SingletonExample.getSingleton();
		
		SingletonExample s2 = 
				SingletonExample.getSingleton();
	
		SingletonExample s3 = 
				SingletonExample.getSingleton();
	
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		
	}

}
