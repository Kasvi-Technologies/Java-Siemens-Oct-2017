package com.siemens.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchEmployeeRecordsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String userName="root";
			String password = "password";
			String url="jdbc:mysql://localhost:3306/siemensdb1";
			
			Connection con = 
					DriverManager.getConnection(url, userName, password);
			
			Statement st = con.createStatement();
			
			//Fetch Records....
			
			String selectQry = "select * from employee";
			
			ResultSet rs = st.executeQuery(selectQry);
			
			while (rs.next()) { 
				//record is available or not
				
				int empId = rs.getInt("empId");
				String empName = rs.getString("empName");
				String emailId = rs.getString("emailId");
				int mobile = rs.getInt("mobile");
				double salary = rs.getDouble("salary");
				
				System.out.println(empId + " " + empName
						+" " + emailId + " " + mobile
						+" " + salary);
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
