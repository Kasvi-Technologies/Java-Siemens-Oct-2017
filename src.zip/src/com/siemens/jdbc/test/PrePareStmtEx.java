package com.siemens.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class PrePareStmtEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String userName="root";
			String password = "password";
			String url="jdbc:mysql://localhost:3306/siemensdb1";
			
			Connection con = 
					DriverManager.getConnection(url, userName, password);
			
			String insertQry = "insert into employee "
					+ "values (?,?,?,?,?)";
			
			PreparedStatement pst = 
					con.prepareStatement(insertQry);
			
			pst.setInt(1, 1000);
			pst.setString(2, "Using Prepared");
			pst.setString(3, "Email id...");
			pst.setInt(4, 657);
			pst.setDouble(5, 6776.90);			
			pst.execute();
			
			pst.setInt(1, 2000);
			pst.setString(2, "Using Prepared2");
			pst.setString(3, "Email idcxv...");
			pst.setInt(4, 65723);
			pst.setDouble(5, 672376.90);
			pst.execute();
			
			
			System.out.println("Inserted............");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
