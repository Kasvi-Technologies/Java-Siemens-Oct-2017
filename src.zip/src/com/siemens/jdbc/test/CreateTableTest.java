package com.siemens.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//JDBC
		//Java database Connectivity
		
		//1. Load the Driver and Register the Driver
		//using reflection, you can load and register the driver
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			//2. Obtain the database connection
			
			String userName="root";
			String password = "password";
			String url="jdbc:mysql://localhost:3306/siemensdb1";
			
			//import should be java.sql
			
			Connection con = 
					DriverManager.getConnection(url, userName, password);
			System.out.println("con:" + con);
			
			// 3. create the statement object
			//statement object is responsible to fire the
			//database queries
			
			Statement st = con.createStatement();
			
			String createQry = "create table employee "
					+ "( empId int primary key, "
					+ "empName varchar(100), "
					+ "emailId varchar(100), "
					+ "mobile int, "
					+ "salary double )";
			
			//Fire a databsae query
			st.execute(createQry);
			
			System.out.println("Table created...");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
