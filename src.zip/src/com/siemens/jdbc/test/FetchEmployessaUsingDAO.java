package com.siemens.jdbc.test;

import java.util.List;

import com.siemens.beans.Employee;
import com.siemens.designpatterns.test.ServiceLocator;
import com.siemens.service.EmployeeService;
import com.siemens.service.EmployeeServiceImpl;

public class FetchEmployessaUsingDAO {

	public static void main(String[] args){
		
		EmployeeService service = 
					ServiceLocator.getEmployeeService();
		
//		EmployeeService service = 
//					new EmployeeServiceImpl();
//		
		List<Employee> empList = 
						service.fetchAllEmployees();
		
		for (Employee emp:empList){
			System.out.println(emp);
		}
	}
}
