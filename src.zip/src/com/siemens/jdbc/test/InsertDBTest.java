package com.siemens.jdbc.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertDBTest {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String userName="root";
			String password = "password";
			String url="jdbc:mysql://localhost:3306/siemensdb1";
			
			Connection con = 
					DriverManager.getConnection(url, userName, password);
			
			Statement st = con.createStatement();
			
			String insertQry = "insert into employee "
					+ "values ( 10, 'Siemens Emp Name', "
					+ "'siemensemp@siemens.com' , 6785, "
					+ "868686);";
			
			st.executeUpdate(insertQry);
			//insert/delete/update
			
			String insertQry1 = "insert into employee "
					+ "values ( 20, 'Siemens Emp Name2', "
					+ "'siemensemp2@siemens.com' , 85, "
					+ "1226)";
			
			st.executeUpdate(insertQry1);
			
			System.out.println("Inserted............");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
