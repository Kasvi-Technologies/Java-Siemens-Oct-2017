package com.siemens.dao;

import java.util.List;

import com.siemens.beans.Employee;

//DAO will contain only Database logic
//Data Access Object

public interface EmployeeDAO {

	//By default, all methods are abstract
	public void insertEmployee(Employee emp);
	public void deleteEmployee(int empId);
	public void updateEmployee(Employee emp);
	public abstract void fetchEmployeeById(int empId);
	public abstract List<Employee> fetchAllEmployees();
}
