package com.siemens.collectionsex.test;

import java.util.Comparator;

import com.siemens.beans.Employee;

public class EmployeeSalaryComparator 
					implements Comparator<Employee>{

	@Override
	public int compare(Employee emp1, Employee emp2) {
		if (emp1.getSalary() < emp2.getSalary()){
			return -1;
		} else if (emp1.getSalary() > emp2.getSalary()){
			return 1;
		} else {
			return 0;
		}
	}

}
