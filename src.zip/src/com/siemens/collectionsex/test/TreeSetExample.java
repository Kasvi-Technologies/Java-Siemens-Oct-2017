package com.siemens.collectionsex.test;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set <Integer> intSet = new TreeSet<Integer>();
		
		intSet.add(500);
		intSet.add(200);
		intSet.add(300);
		intSet.add(700);
		boolean flag = intSet.add(700);
		
		if (flag == false) {
			//it is unable to add the element, that means
			//it might be duplicate
			System.out.println("Duplicate");
		}
		intSet.add(300);
		intSet.add(100);
		
		System.out.println("Size:" + intSet.size());
		
		
		//Display using Enhanced for loops
		
		for (Integer in : intSet) {
			System.out.println(in);
		}
		//Display using iterator approach
		
	}

}
