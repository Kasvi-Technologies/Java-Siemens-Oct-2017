package com.siemens.collectionsex.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetStringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set <String> strSet = new TreeSet<String>();
		strSet.add("Ddsfdsfdsf");
		strSet.add("As");
		strSet.add("ghghgh");
		strSet.add("bdgffdgfdg");
		strSet.add("Zdsfdsfdsf");
		strSet.add("as");
		strSet.add("ZZZZdsfdsfdsf");
		
		System.out.println("Using Enhanced for loops...");
		for (String str : strSet) {
			System.out.println(str);
		}
		
		//Display using iterator approach
		System.out.println("Using Iterator approach..");
		Iterator<String> strSetItr = strSet.iterator();
		while(strSetItr.hasNext()){
			System.out.println(strSetItr.next());
		}
		
		
	}

}

