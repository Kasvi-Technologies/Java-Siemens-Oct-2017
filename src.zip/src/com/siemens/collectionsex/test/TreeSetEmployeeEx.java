package com.siemens.collectionsex.test;

import java.util.Set;
import java.util.TreeSet;

import com.siemens.beans.Employee;

public class TreeSetEmployeeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set<Employee> empSet = new TreeSet<Employee>();		
		
		Employee emp1 = new Employee (500, "dsf","dsf", 65765, 1980);
		Employee emp2 = new Employee (200, "asd","dsf", 65765, 766765);
		Employee emp3 = new Employee (100, "wrwr","dsf", 65765, 78);
		Employee emp4 = new Employee (800, "vbvn","dsf", 65765, 13123);
		Employee emp5 = new Employee (600, "tyr","dsf", 65765, 909);
		
		empSet.add(emp1);
		empSet.add(emp2);
		empSet.add(emp3);
		empSet.add(emp4);
		empSet.add(emp5);
		
		System.out.println("Normal Sorting based on Employee class");
		for (Employee emp : empSet){
			System.out.println(emp);
		}
		
		System.out.println(" Sorting based on EmployeeSalaryComparator");
		
		Set<Employee> empSet1 = 
				new TreeSet<Employee>(new EmployeeNameComparator());		
		
		empSet1.add(emp1);
		empSet1.add(emp2);
		empSet1.add(emp3);
		empSet1.add(emp4);
		empSet1.add(emp5);
		
		for (Employee emp : empSet1){
			System.out.println(emp);
		}
		
	}

}
