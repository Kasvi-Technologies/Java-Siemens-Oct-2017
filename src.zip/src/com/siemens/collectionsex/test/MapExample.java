package com.siemens.collectionsex.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//map is key and value pair
		
		Map<Integer, String> m = 
					new HashMap<Integer, String>();
		
		m.put(100, "safdsdfsaf");		
		m.put(500, "safdsdfsaf");		
		m.put(600, "safdsdfsaf");		
		m.put(300, "safdsdfsaf");		
		m.put(200, "safdsdfsaf");
		
		System.out.println("Map Size:" + m.size());
		
		System.out.println("Value for key 600:"+ m.get(600));
		
		//repeat your collection
		//You will not have Iterator in Map, since it is
		//not from the collection class
		
		Set<Integer> keySet = m.keySet();
		
		Iterator<Integer> keySetItr = keySet.iterator();
		while(keySetItr.hasNext()){
			Integer key = keySetItr.next();
			String value = m.get(key);
			System.out.println(key + " " + value);		
		}
		
		
	}
}
