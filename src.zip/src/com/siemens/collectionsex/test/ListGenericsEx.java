package com.siemens.collectionsex.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListGenericsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Generics will restrict the collection so that 
		// collection can hold only one particular Object
		
		List<Integer> intList = new ArrayList<Integer>();
		
		intList.add(100);
		intList.add(500);
		intList.add(200);
		intList.add(900);
		intList.add(300);
		
		System.out.println("Using Normal For Loops...");
		for (int i = 0; i < intList.size();i++){
			System.out.println(intList.get(i));
		}
		
		System.out.println("Enhanced For Loops...");
		for (Integer in : intList){
			System.out.println(in);
		}
		
		System.out.println("using Iterator...");
		Iterator<Integer> intListItr = 
									intList.iterator();
		while(intListItr.hasNext()) {
			int intValue = intListItr.next();
			System.out.println(intValue);
		}
		
		intList.remove(2);
		
		System.out.println("Size after removal:" 
								+ intList.size());
		
	}

}
