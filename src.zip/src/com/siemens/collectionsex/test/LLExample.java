package com.siemens.collectionsex.test;

import java.util.LinkedList;
import java.util.List;

public class LLExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> strList = new LinkedList<String>();
		
		strList.add("Hi");
		strList.add("How");
		strList.add("Are");
		strList.add("you");
		
		System.out.println(strList.get(2));
		for (String str : strList) {
			System.out.println(str);
		}
	}

}
