package com.siemens.collectionsex.test;

import java.util.ArrayList;
import java.util.List;

import com.siemens.beans.Employee;

public class ListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ParentClass var = new ChildClass();
		//ChildClass var = new ChildClass();
		
		List list = new ArrayList();
		
		int i1 = 100;
		list.add(i1); 
		
		//list.add(new Integer(i1));
		
		//For every primitive data type, there is a 
		//wrapper class
		
		//int -> Integer
		//byte -> Byte
		//short -> Short
		//long -> Long
		
		//float -> Float
		//double -> Double
		
		//char -> Char
		
		//boolean -> Boolean
		list.add(200);
		
		list.add("Hi");
		list.add("How r u");
		
		list.add(2, "Good Morning");
		list.add(0, "modified the 0th loc");
		
		
		
		Employee emp = 
				new Employee(100, "dsfdf", "sadsda", 5656,5665);
		
		list.add(emp);
		
		System.out.println(list.size());
		
		//get method is used to retrieve the element from list
		for (int i = 0; i < list.size(); i++){
			System.out.println(list.get(i));
			Integer inte = (Integer) list.get(i);
			int v = inte.intValue();
			//
		}
		
		
	}

}
