package com.siemens.beans;

public class CalculatorImpl extends Calculator {

	@Override
	public int sum(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	
	@Override
	public int minus (int a, int b){
		return a - b;
	}

	

}
