package com.siemens.beans;

public class Vehicle {

	//Data Hiding
	private int vId;
	private String vname;
	private double cost;
	
	//Encapsulation
	//setter and Getter emthods..
	
	public void drive(){
		System.out.println("Vehicle class drive functionality..");
		System.out.println("*********************");
	}
	
		
	public int getvId() {
		return vId;
	}
	public void setvId(int vId) {
		this.vId = vId;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
	
}
