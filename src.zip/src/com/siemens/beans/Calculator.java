package com.siemens.beans;

public abstract class Calculator {

	//Abstraction
	//It will specify only essential features 
	//(entire method signature) with out informing 
	//any inner details (implementation).	
	public abstract int sum (int a, int b);
	
	//Abstract class can contain Abstract methods and 
	//non-abstract methods...
	
	public int minus (int a, int b){
		return a - b;
	}
}
