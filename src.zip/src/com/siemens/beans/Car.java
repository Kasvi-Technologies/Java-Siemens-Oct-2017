package com.siemens.beans;

public class Car extends Vehicle{

	//Method Overriding
	public void drive() {
		super.drive();
		System.out.println("Driving the car " + 
								this.getVname());
	}
	
	//Method Overloading
	public void drive(int speed) {
		System.out.println("Method Overloading from car class");
	}
	
}

