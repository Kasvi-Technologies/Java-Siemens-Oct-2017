package com.siemens.beans;

import java.io.Serializable;

//Coding Standards
//Class name will start with a Capital letter and 
//all SubSequent words  will start a capital letters

//Java POJO classes
//Java Beans

public class Employee 
		implements Comparable<Employee>, Serializable
{


	@Override
	public int compareTo(Employee arg0) {
		if (this.getEmpId() < arg0.getEmpId()){
			return -1;
		} else if (this.getEmpId() > arg0.getEmpId()){
			return 1;
		} else {
			return 0;
		}
	}
	
	
	//Variables, firstletter will be small letter
	//and all SubSequent words  will start a capital letters
	
	public Employee(){
		System.out.println("Inside constructor..");
	}
	
	public Employee(int empId, String empName, 
			String emailId, int mobile, double salary){
		System.out.println("Inside parameterized constructor..");
		this.empId  = empId;
		this.empName  = empName;
		this.emailId = emailId;
		this.mobile = mobile;
		this.salary = salary;
	}
		
	private int empId;
	private String empName;
	private String emailId;
	private int mobile;
	private double salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	//Generate Getters and Setters....
	
	public String toString(){
		
		return this.getEmpId() + " " + 
			   this.getEmpName() +" " + 
			   this.getEmailId() + " " +
			   this.getMobile() +" " + 
			   this.getSalary();
				
	}

	
}
