package com.siemens.beans;

public class Bike extends Vehicle{

	public void drive() {
		System.out.println("Driving the bike " + 
								this.getVname());
	}
	
}
