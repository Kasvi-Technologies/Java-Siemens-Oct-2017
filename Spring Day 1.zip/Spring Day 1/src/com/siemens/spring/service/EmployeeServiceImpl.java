package com.siemens.spring.service;

import com.siemens.spring.core.Employee;
import com.siemens.spring.dao.EmployeeDAO;

public class EmployeeServiceImpl 
					implements EmployeeService{

	private EmployeeDAO employeeDAO;
	//not using new operator...
	//spring will create an instance for employeeDAO
	
	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

	@Override
	public void insertEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDAO.insertEmployee(emp);
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		employeeDAO.deleteEmployee(empId);	
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDAO.updateEmployee(emp);
	}

	@Override
	public void fetchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		employeeDAO.fetchEmployeeById(empId);
	}

	@Override
	public void fetchAllEmployees() {
		// TODO Auto-generated method stub
		employeeDAO.fetchAllEmployees();
	}

}
