package com.siemens.spring.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.siemens.spring.core.HelloWorld;

public class CoreBasicTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//ParentClass p = new ChildClass();
		
		BeanFactory factory = 
				new XmlBeanFactory
				(new FileSystemResource("src\\beans.xml"));
		
		
		HelloWorld h = (HelloWorld) 
					factory.getBean("helloWorld");
		
		System.out.println(h);
		System.out.println(h.getMessage());
		
		
	}

}
