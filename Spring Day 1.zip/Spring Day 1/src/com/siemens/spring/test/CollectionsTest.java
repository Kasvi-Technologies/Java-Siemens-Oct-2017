package com.siemens.spring.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.siemens.spring.core.CollectionEx;
import com.siemens.spring.core.HelloWorld;

public class CollectionsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BeanFactory factory = 
				new XmlBeanFactory
				(new FileSystemResource("src\\beans.xml"));
		
		
		CollectionEx c = (CollectionEx) 
					factory.getBean("collectionExample");
		
		
		System.out.println(c.getaList());
		System.out.println(c.getaSet());
		System.out.println(c.getAmap());
	}

}
