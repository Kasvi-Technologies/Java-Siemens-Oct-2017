package com.siemens.spring.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

import com.siemens.spring.core.Employee;
import com.siemens.spring.core.HelloWorld;
import com.siemens.spring.service.EmployeeService;

public class EmpTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//load the file from file system
//		BeanFactory factory = 
//				new XmlBeanFactory
//				(new FileSystemResource("src\\beans.xml"));
//		
		//load the xml file from classpath
		//ApplicationContext is subclass of beanfactory
		
		//By default, Lazy initialization is disabled
		
		//It will try to create all bean instances, which
		//are registered in xml file
		
		ApplicationContext factory = 
			new ClassPathXmlApplicationContext("beans.xml");
				
//		Employee employee1 = (Employee) 
//					factory.getBean("emp1");
//		
		Employee employee1 = 
				factory.getBean("emp1", Employee.class);
		
		//lazy-init="true"
		//factory.getBean("helloWorld");//
		
		System.out.println("emp1:" + employee1);
		
		System.out.println(employee1.getId() + " " 
					+ employee1.getName() + " " 
					+ employee1.getSalary() );
		
		System.out.println(employee1.getAddress().getAddressId());
		Employee employee2 = (Employee) 
				factory.getBean("emp2");
	
		System.out.println("emp2:" + employee2);
		
		System.out.println(employee2.getId() + " " 
					+ employee2.getName() + " " 
					+ employee2.getSalary() );
		
		System.out.println(employee2.getAddress().getAddressId());
	
		System.out.println("Address objects");
		System.out.println(employee1.getAddress());
		
		System.out.println(employee2.getAddress());
		
		
		EmployeeService employeeService = 
				(EmployeeService) 
				factory.getBean("employeeService");
		
		employeeService.insertEmployee(employee1);
	}

}
