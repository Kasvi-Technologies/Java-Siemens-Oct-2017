package com.siemens.spring.dao;

import com.siemens.spring.core.Employee;

public interface EmployeeDAO {

	public abstract void insertEmployee(Employee emp);
	public abstract void deleteEmployee(int empId);
	public abstract void updateEmployee(Employee emp);
	public abstract void fetchEmployeeById(int empId);
	public abstract void fetchAllEmployees();
	
}
