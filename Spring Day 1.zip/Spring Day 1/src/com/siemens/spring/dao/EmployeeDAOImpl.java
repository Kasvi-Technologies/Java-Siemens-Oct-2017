package com.siemens.spring.dao;

import com.siemens.spring.core.Employee;

public class EmployeeDAOImpl 
					implements EmployeeDAO{

	@Override
	public void insertEmployee(Employee emp) {
		// TODO Auto-generated method stub
	
		System.out.println("DAO:insertEmployee" );
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		System.out.println("DAO:deleteEmployee" );
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("DAO:updateEmployee" );
	}

	@Override
	public void fetchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		System.out.println("DAO:fetchEmployeeById" );
	}

	@Override
	public void fetchAllEmployees() {
		// TODO Auto-generated method stub
		System.out.println("DAO:fetchAllEmployees" );
	}	
	

}
