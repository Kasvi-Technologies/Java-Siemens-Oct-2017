package com.siemens.spring.dao;

import org.springframework.stereotype.Repository;

import com.siemens.spring.core.Product;

@Repository("productDAO")

public class ProductDAOmpl implements ProductDAO{

	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		System.out.println("ProductDAOmpl:" + p.getId());
	}

}
