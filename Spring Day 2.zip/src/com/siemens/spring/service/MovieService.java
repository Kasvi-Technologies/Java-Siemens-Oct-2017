package com.siemens.spring.service;

public interface MovieService {

	public void fetchMovie(int theatreId);
}
