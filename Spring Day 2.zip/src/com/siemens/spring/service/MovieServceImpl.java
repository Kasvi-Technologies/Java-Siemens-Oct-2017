package com.siemens.spring.service;

public class MovieServceImpl 
	implements MovieService {

	@Override
	public void fetchMovie(int theatreId) {
		// TODO Auto-generated method stub
		System.out.println("fetching movie with threate id" + theatreId);
	}

}
