package com.siemens.spring.core;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Employee 
			implements InitializingBean,
			DisposableBean {
	
	
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("after properties set..");
	}
	

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("destroy method....");
	}
	
	
	//init-method="initMethod"
	public void initMethod(){
		//This method will be executed after completion of
		//all setter methods to perform some
		//business logic based on the properties set
		
		System.out.println("Init method executed after all setter methods..");
	}	
	//destroy-method="cleanup"
	public void cleanup(){
		//This business logic will be executed at the 
		// time of garbage colletion
		
		//that means, this method wll be executed at the time of
		//removing the reference from memory
		
		System.out.println("clean up related logc...");
	}
	
	//As of now, spring uses this Default constructor
	public Employee(){
		
	}	
	
	public Employee(int id, String name, 
			double salary, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}

	private int id;
	private String name;
	private double salary;
	
	private String empDescription;
	public String getEmpDescription() {
		return empDescription;
	}
	public void setEmpDescription(String empDescription) {
		this.empDescription = empDescription;
	}

	private Address address;	
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}


	
	
}
