package com.siemens.spring.core;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Theatre {

	public Theatre () {
		
	}
	
	//autowire="constructor"
	public Theatre(Movie movie, Movie movie1){
		this.movie = movie;
		this.movie1 = movie1;
	}
	
	private int id;
	private String name;
	private String location;
	private Movie movie;
	private Movie movie1;	
	
	public Movie getMovie1() {
		return movie1;
	}
	@Required
	@Autowired
	@Qualifier("movie5")
	public void setMovie1(Movie movie1) {
		this.movie1 = movie1;
	}
	public int getId() {
		return id;
	}
	
	@Required
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Movie getMovie() {
		return movie;
	}
	
	@Required
	@Autowired
	@Qualifier("movie6")
	//annotation will use concept of byType
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	//init-method or InitializingBean interface
	
	@PostConstruct
	public void init(){
		System.out.println("Post construct logic");
	}
	
	//destroy-method or DisposableBean
	@PreDestroy
	public void destroy(){
		System.out.println("releasing the resources..");
	}
		
}
