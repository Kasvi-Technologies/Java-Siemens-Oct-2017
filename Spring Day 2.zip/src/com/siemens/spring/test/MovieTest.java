package com.siemens.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Movie;
import com.siemens.spring.core.Theatre;
import com.siemens.spring.service.MovieService;

public class MovieTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = 
		   new ClassPathXmlApplicationContext("moviebeans.xml");
		
		Theatre theatre = 
				factory.getBean("theatre", Theatre.class);
		
		System.out.println(theatre.getId() + " " +
							theatre.getName() + " " +
							theatre.getLocation() );
		
		Movie movie = theatre.getMovie();
		System.out.println(movie.getId() + " " +
				movie.getName() + " " +
				movie.getPrice() );
		
		MovieService movieService = 
				factory.getBean("movieService", MovieService.class);
		
		movieService.fetchMovie(theatre.getId());
		
		
		System.out.println("Ex of autowire byName..");
		//autowire="byName"
		Theatre theatreByName = 
				factory.getBean("theatreByName", Theatre.class);
		
		System.out.println(theatreByName.getMovie().getId());
		System.out.println("movie1:" +
						theatreByName.getMovie1());
		
		System.out.println("Ex of autowire byType..");
		
		//autowire="byType"
		//Reference type should be only one in xml file
		Theatre theatreByType = 
				factory.getBean("theatreByType", Theatre.class);
		
		System.out.println(theatreByType.getMovie().getId());
		System.out.println("movie1:" +
						theatreByType.getMovie1());
		System.out.println("movie1 id:" +
				theatreByType.getMovie1().getId());

		
		System.out.println("Ex of autowire constructor..");
		
		//autowire="constructor"
		//it will inject using parameterized
		//constructor using concept of byType
		
		Theatre theatreByCon = 
				factory.getBean("theatreByCon", Theatre.class);
		
		System.out.println(theatreByCon.getMovie().getId());
		System.out.println("movie1:" +
				theatreByCon.getMovie1());
		System.out.println("movie1 id:" +
				theatreByCon.getMovie1().getId());

		
		//autowire="autodetect"
		// if default constructor found, then it will use
		//byType approach
		
		//If parameterized constructor founds, then it
		//will use constructor approach

		Theatre theatreByAuto = 
				factory.getBean("theatreByAuto", Theatre.class);
		
		System.out.println(theatreByAuto.getMovie().getId());
		System.out.println("movie1:" +
				theatreByAuto.getMovie1());
		System.out.println("movie1 id:" +
				theatreByAuto.getMovie1().getId());

		
		System.out.println("theatreByAnnotationAutowred");
		
		Theatre theatreByAnnotationAutowred = 
				factory.getBean("theatreByAnnotationAutowred", Theatre.class);
		System.out.println(theatreByAnnotationAutowred.getMovie().getId());
		
		
	}

}
