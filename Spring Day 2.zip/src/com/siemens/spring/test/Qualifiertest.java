package com.siemens.spring.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.siemens.spring.core.Theatre;

public class Qualifiertest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext factory = 
			 new ClassPathXmlApplicationContext("qualifier.xml");
				
		Theatre theatre = 
				factory.getBean("theatre", Theatre.class);
			
		System.out.println(theatre.getMovie().getId());
		System.out.println(theatre.getMovie1().getId());
	}

}
