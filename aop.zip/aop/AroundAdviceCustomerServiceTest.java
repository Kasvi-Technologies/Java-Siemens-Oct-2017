package com.samples.aop.customerservice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AroundAdviceCustomerServiceTest {
	 public static void main( String[] args )
	    {
	    	ApplicationContext appContext = 
	    	  new ClassPathXmlApplicationContext(new String[] {"Spring-Customer.xml"});
	 
	    	CustomerService cust = 
	          (CustomerService)appContext.getBean("customerServiceAroundAdviceProxy");
	 
	    	System.out.println("*************************");
	    	cust.printName();
	    	System.out.println("*************************");
	    	cust.printURL();
	    	System.out.println("*************************");
	    	try{
	    		cust.printThrowException();
	    	}catch(Exception e){
	 
	    	}
	    	
	    	/*
	    	 * It will run the HijackAroundMethod�s invoke() method, after every customerService�s
	    	 *  method execution.
	    	 */
	 
	    }

}
