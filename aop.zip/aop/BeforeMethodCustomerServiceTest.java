package com.samples.aop.customerservice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeforeMethodCustomerServiceTest {
	 public static void main( String[] args )
	    {
	    	ApplicationContext appContext = 
	    	  new ClassPathXmlApplicationContext(new String[] {"Spring-Customer.xml"});
	 
	    	CustomerService cust = 
	          (CustomerService)appContext.getBean("customerServiceProxy");
	 
	    	System.out.println("*************************");
	    	cust.printName();
	    	System.out.println("*************************");
	    	cust.printURL();
	    	System.out.println("*************************");
	    	try{
	    		cust.printThrowException();
	    	}catch(Exception e){
	 
	    	}
	    	
	    	/*
	    	 * It will run the HijackBeforeMethod�s before() method, before every customerService�s 
	    	 * methods are execute.
	    	 * 
	    	 */
	 
	    }

}
