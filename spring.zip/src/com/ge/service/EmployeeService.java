package com.ge.service;

import java.util.ArrayList;
import java.util.List;

import com.ge.coreex.Employee1;
import com.ge.dao.EmployeeDAO;

//BL
//call the dao's to perform db logic
public class EmployeeService {
//	/parameterized constructor instead of setter methods..
	private EmployeeDAO employeeDAO;

//	public EmployeeService(EmployeeDAO employeeDAO) {
//		this.employeeDAO = employeeDAO;
//	}
	
	public EmployeeDAO getEmployeeDAO() {
		return employeeDAO;
	}

	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	public void addEmployee(Employee1 employee) {
		//BL
		///success..
		getEmployeeDAO().addEmployee(employee);
		
	}
	
	public List<Employee1> getEmployeeList() {
		//BL
		return employeeDAO.getEmployeeList();
	}
	
	

}
