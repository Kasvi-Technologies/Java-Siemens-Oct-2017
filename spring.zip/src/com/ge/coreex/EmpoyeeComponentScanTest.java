package com.ge.coreex;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpoyeeComponentScanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/ge/coreex/beans.xml");
		
		System.out.println(context.getBean("employee1"));

	}

}
