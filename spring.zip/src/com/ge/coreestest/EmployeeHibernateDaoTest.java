package com.ge.coreestest;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.coreex.Employee1;
import com.ge.dao.EmployeeDAO;
import com.ge.dao.EmployeeHibernateDAO;

public class EmployeeHibernateDaoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
				new ClassPathXmlApplicationContext
				("com/ge/dao/beans.xml");
		
		EmployeeHibernateDAO dao = (EmployeeHibernateDAO) 
							context.getBean("employeeHibernateDAO");
		
		Employee1 emp = new Employee1();
		emp.setId(111);
		emp.setName("DAO Example");
		emp.setSalary(32423);
		
		dao.addEmployee(emp);
		
		Employee1 emp1 = dao.getEmployeeBasedOnID(1);
		if(emp1!=null)
			System.out.println(emp1.getName());
		
		List<Employee1> empList = dao.getEmployeeList();
		System.out.println(empList.size());
	}

}
