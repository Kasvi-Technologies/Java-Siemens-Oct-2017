package com.ge.coreestest;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.xml.sax.InputSource;

import com.ge.coreex.Employee1;
import com.ge.service.EmployeeService;

public class DItest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Employee e = new Employee();
		
		BeanFactory factory = 
				new XmlBeanFactory
				(new FileSystemResource("bin/beans.xml"));
		
		//Setter based DI/IOC
		Employee1 emp = (Employee1)factory.getBean("employee");
		System.out.println(emp.getName() + " " + emp.getId());
		
		Employee1 emp1 = (Employee1)factory.getBean("employee1");
		System.out.println(emp1.getName() + " " + emp1.getId());
		
		//Constructer Based Dependency INjection
		Employee1 emp2 = (Employee1)factory.getBean("employee2");
		System.out.println(emp2.getName() + " " + emp2.getId());
		
		//Constructer Based and Setter based Dependency INjection
		Employee1 emp3 = (Employee1)factory.getBean("employee3");
		System.out.println(emp3.getName() + " " + emp3.getId()
							+" " + emp3.getSalary());
		
		//DI Example using service and DAO classes
		
		EmployeeService employeeService = 
				(EmployeeService)factory.getBean("employeeService");
		
		EmployeeService employeeService1 = 
				(EmployeeService)factory.getBean("employeeService1");
		
		System.out.println(employeeService.getEmployeeDAO());
		System.out.println(employeeService1.getEmployeeDAO());
		
		employeeService.addEmployee(emp);
				
	}

}
