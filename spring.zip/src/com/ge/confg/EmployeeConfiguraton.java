package com.ge.confg;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ge.dao.EmployeeDAO;
import com.ge.service.EmployeeService;

@Configuration
public class EmployeeConfiguraton {
	
	@Bean
	@Scope("prototype")
	public EmployeeService employeeService() {
		return new EmployeeService();
	}
	
	@Bean
	public EmployeeDAO employeeDAO() {
		return new EmployeeDAO();
	}

}
