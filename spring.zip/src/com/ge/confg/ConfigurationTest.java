package com.ge.confg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ge.service.EmployeeService;

public class ConfigurationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx = 
				new AnnotationConfigApplicationContext
							(EmployeeConfiguraton.class);
		
		EmployeeService eService = (EmployeeService) 
						ctx.getBean("employeeService");
		
		EmployeeService eService1 = (EmployeeService) 
				ctx.getBean("employeeService");

		System.out.println(eService);
		
		System.out.println(eService1);
			
		
	}

}
