package com.ge.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.ge.coreex.Employee1;

//DAO Design pattern
//Ths should contain only database logic
public class EmployeeDAO extends JdbcDaoSupport{
	
	public void addEmployee(Employee1 employee) {		
		System.out.println("addEmployee method from DAO for adding id" +
						employee.getId());
		
		int id=employee.getId();
		String name= employee.getName();
		double salary = employee.getSalary();
		
		String sql = "insert into employee1 values("
							+id+",'"+name+"',"+salary+")";
		//this.jdbcTemplate.execute(sql);
		this.getJdbcTemplate().execute(sql);
		
	}
	
//	public int getEmployeeCount() {
//		
//		//return	this.getJdbcTemplate().queryF
//		
//	}
//	
	public List<Employee1> getEmployeeList() {		
		List<Employee1> empList  = 
			this.getJdbcTemplate().query("select * from employee1"
				, new EmployeeRowMapper());		
		return empList;
	}	
}

class EmployeeRowMapper implements RowMapper<Employee1>{
	public Employee1 mapRow(ResultSet rs, int arg1)
			throws SQLException {
		Employee1 emp = new Employee1();
		emp.setId(rs.getInt(1));
		emp.setName(rs.getString(2));
		emp.setSalary(rs.getDouble(3));
		return emp;
	}	
}
