package com.ge.dao;

import java.util.List;

import org.hibernate.FlushMode;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.ge.coreex.Employee1;

public class EmployeeHibernateDAO {
	
	private HibernateTemplate hibernateTemplate;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
		hibernateTemplate.setCheckWriteOperations(false);
	}
	
	public void addEmployee(Employee1 employee) {		
		//this.hibernateTemplate.getSessionFactory().getCurrentSession().setFlushMode(FlushMode.AUTO);
		this.hibernateTemplate.save(employee);
	}
	
	public List<Employee1> getEmployeeList() {	
		List<Employee1> empList = 
					(List<Employee1>) this.hibernateTemplate.find("from Employee1");
		return empList;
	}
	
	public Employee1 getEmployeeBasedOnID(int id) {	
		Employee1 emp= 
				this.hibernateTemplate.get(Employee1.class, id);
		return emp;
	}

}
