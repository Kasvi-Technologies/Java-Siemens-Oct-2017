package com.ge.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ge.coreex.Employee1;

public class DAOTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
				new ClassPathXmlApplicationContext
				("com/ge/jdbcdaoexamples/beans.xml");
		
		EmployeeDAO dao = (EmployeeDAO) context.getBean("employeeDAO");
		
		Employee1 emp = new Employee1();
		emp.setId(20001);
		emp.setName("DAO Example");
		emp.setSalary(32423);
		
		dao.addEmployee(emp);
		
		System.out.println("count:" + dao.getEmployeeList().size());
		
	}

}
