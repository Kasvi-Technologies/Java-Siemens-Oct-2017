package com.samples.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class EmployeeBasicTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		 BeanFactory factory = new XmlBeanFactory
		 		(new FileSystemResource("src\\com\\samples\\test\\beans.xml"));

		 Employee e = (Employee)factory.getBean("employee");
		 
		 System.out.println(e.getId());
		 
	}

}
