package com.samples.jdbc.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class ProductDAO extends JdbcDaoSupport {
	
	public void insertProduct(int id, String name, 
			String productDesc) {
		
		String sql = "insert into product values ("
			+id +" , '" + name + "' , '" + productDesc 
			+ "' )";
		
		this.getJdbcTemplate().update(sql);
		
	}

}
