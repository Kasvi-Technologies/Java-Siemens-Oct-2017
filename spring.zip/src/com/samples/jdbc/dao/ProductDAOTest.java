package com.samples.jdbc.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProductDAOTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
		"com/samples/jdbc/dao/dao.xml");
		
		ProductDAO productDAO = (ProductDAO) 
				context.getBean("productDAO");
		
		productDAO.insertProduct(1, "Car", "Honda.");
		
		
	}

}
