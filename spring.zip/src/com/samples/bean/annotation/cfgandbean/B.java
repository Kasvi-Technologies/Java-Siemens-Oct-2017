package com.samples.bean.annotation.cfgandbean;

public class B {

}
