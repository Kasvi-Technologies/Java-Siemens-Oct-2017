package com.samples.bean.annotation.cfgandbean;


import org.springframework.context.annotation.*;

/**
 * below code will be equivalent to the following XML configuration:

<beans>
   <bean id="helloWorld" class="com.....HelloWorld" />
</beans>
 * @author kancha1
 *
 */
@Configuration
public class HelloWorldConfig {

   @Bean(name="helloWorld")
 
   public HelloWorld helloWorld(){
      return new HelloWorld();
   }
}