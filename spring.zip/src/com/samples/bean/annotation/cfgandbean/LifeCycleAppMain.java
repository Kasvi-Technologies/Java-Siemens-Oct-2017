package com.samples.bean.annotation.cfgandbean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class LifeCycleAppMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 ApplicationContext ctx = 
			    new AnnotationConfigApplicationContext(LifeCycleAndScopeConfig.class);
		 LifeCycle lifeCycle = ctx.getBean(LifeCycle.class);
		 System.out.println(lifeCycle);
		 
		 LifeCycle lifeCycle1 = ctx.getBean(LifeCycle.class);
		 System.out.println(lifeCycle1);
		 
	}

}
