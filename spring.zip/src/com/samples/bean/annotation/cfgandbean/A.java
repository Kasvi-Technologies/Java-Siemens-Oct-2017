package com.samples.bean.annotation.cfgandbean;

public class A extends B {

}
