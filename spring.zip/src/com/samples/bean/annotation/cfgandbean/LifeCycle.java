package com.samples.bean.annotation.cfgandbean;

public class LifeCycle {
	   public void init() {
	      // initialization logic
	   }
	   public void cleanup() {
	      // destruction logic
	   }
	}