package com.dependencycheck.annotation.required;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Customer 
{
	private Person person;
	private int type;
	private String action;
 
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Person getPerson() {
		return person;
	}

	//based on byType
	
	@Required
	@Autowired
	@Qualifier("personBean1")
	public void setPerson(Person person) {
		this.person = person;
	}
}