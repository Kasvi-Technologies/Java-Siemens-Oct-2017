package com.dependencycheck.annotation.required;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext(
		"com/dependencycheck/annotation/required/dcrequired.xml");


		Customer cust = (Customer) context.getBean("CustomerBean");
		System.out.println(cust.getPerson().getName());
	}

}
