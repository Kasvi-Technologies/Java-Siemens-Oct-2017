package com.comviva.hibernate.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HibernateDAOTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
					"SpringAndHibernate.xml");
		
		ProductHibernateDAO productHibernateDao = 
				(ProductHibernateDAO) 
				context.getBean("productHibernateDao");
		
		Product product = new Product();
		
		//assigned generator class
		product.setProd_id(200);
		product.setProd_name("xcvcb");
		product.setProd_desc("Spring and Hibernate");
		
		productHibernateDao.insertProduct(product);
		
	}

}
