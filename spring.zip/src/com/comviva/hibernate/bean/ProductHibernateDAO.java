package com.comviva.hibernate.bean;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class ProductHibernateDAO extends 
					HibernateDaoSupport {
	
//	with out Hibernate DAO Support
//	private HibernateTemplate hibernateTemplate;
//	public void setSessionFactory(SessionFactory sessionFactory) {
//		this.hibernateTemplate = new 
//					HibernateTemplate(sessionFactory);
//	}
//
//	
	public void insertProduct(Product product) {
		this.getHibernateTemplate().save(product);
	}

}
