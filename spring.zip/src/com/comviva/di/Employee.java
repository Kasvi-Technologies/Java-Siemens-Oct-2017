package com.comviva.di;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.config.BeanDefinition;

//<bean id="employee" class="...Employee"/>

@Component("emp")

@Scope(BeanDefinition.SCOPE_SINGLETON)

//@Scope("singleton")

public class Employee {

		
	private int empId;
	private String name;
		
	@Autowired(required=true)
	@Qualifier("address1")
	private Address address;
	
	public Employee () {
		
	}
	
	public Employee (int empId, Address address) {
		this.empId = empId;
		this.address = address;
	}
	
	public int getEmpId() {
		return empId;
	}
	
	@Required
	@Value("100")
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@PostConstruct
	public void initIt() throws Exception {
	  System.out.println("Init method after properties are set : ");
	}
 
	@PreDestroy
	public void cleanUp() throws Exception {
	  System.out.println("Spring Container is destroy! Customer clean up");
	}

	
	
}