package com.comviva.di;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class ConstructorDITest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 BeanFactory factory = new XmlBeanFactory
		 		(new FileSystemResource("src\\beans.xml"));

		 /*
		  * <bean id="employeeUsingCon" class="com.comviva.di.Employee" 
		  * scope="prototype">
		  */
		 Employee emp = (Employee) factory.getBean("employee2");
		 Employee emp1 = (Employee) factory.getBean("employee3");
		 
		 System.out.println("emp:" + emp);
		 System.out.println("emp1:" + emp1);
		 
		 // Start Business logic using employee class
		 
//		 System.out.println(emp.getEmpId());
//		 System.out.println(emp.getName());
//		 System.out.println(emp.getAddress().getAddress1());
		
	}

}
