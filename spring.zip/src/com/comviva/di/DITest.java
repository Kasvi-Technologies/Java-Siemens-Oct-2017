package com.comviva.di;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class DITest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = 
			new ClassPathXmlApplicationContext(
		"annotationexamples.xml");
		
		Employee e = (Employee) context.getBean("emp");
		System.out.println(e.getAddress());
		
	}

}
