package cfgandbean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.comviva.hibernate.bean.Product;

public class CfgTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ctx = 
			new AnnotationConfigApplicationContext
						(SpringConfiguration.class);
				
		Product p = (Product) ctx.getBean(Product.class);
		
		System.out.println(p);

	}

}
