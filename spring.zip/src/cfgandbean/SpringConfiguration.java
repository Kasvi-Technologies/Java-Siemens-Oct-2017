package cfgandbean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.comviva.hibernate.bean.Product;

// Using @Configuration and @Bean annotations,
//we can avoid creating the configuration files
// like beans.xml
//<bean id="product" class="com...Product"/>

@Configuration
class SpringConfiguration {
	@Bean
	@Scope("prototype")
	public Product product() {
		return new Product();	
	}
}